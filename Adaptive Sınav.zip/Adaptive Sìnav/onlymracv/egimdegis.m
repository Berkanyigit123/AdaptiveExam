clear; clc;

% Araç parametreleri
m = 1400;
Cd = 0.3;
rho = 1.25;
A = 3;
idisli = 3.58;
rteker = 0.35;
g = 9.81;
Fmekanik = 182;

% MRAC parametreleri
gamma1 = 0.01; gamma2 = 0.01;
am = 0.2; bm = 7;
v_ref = 35;

% Başlangıç değerleri
v = 0;
vm = 0;
theta1_hat = 0;
theta2_hat = 0;

% Zaman ayarları
dt = 0.01;
T = 100;
t = 0:dt:T;

% Kayıt değişkenleri
V = zeros(1, length(t));
Vm = zeros(1, length(t));
E = zeros(1, length(t));
Theta1 = zeros(1, length(t));
Theta2 = zeros(1, length(t));
Tmotor = zeros(1, length(t));

for k = 1:length(t)

    %Zorlayıcı ama gerçekçi koşullar
    vrand = 10 * sin(0.1 * t(k));                    % ±10 m/s rüzgar
    egim = deg2rad(7 * sin(0.1 * t(k)));             % ±7 derece eğim

    % Kuvvet hesapları
    Faero = 0.5 * rho * Cd * A * (v + vrand)^2;
    Fe = m * g * sin(egim);

    % MRAC kontrolcü torku
    T_motor = theta1_hat * v + theta2_hat * v_ref;

    %Motor fiziksel tork sınırları uygulanıyor (satürasyon)
    T_motor = max(min(T_motor, 270), -130);  % +270/-130 Nm sınırları

    Tmotor(k) = T_motor;

    % Motor kuvveti
    Fmotor = T_motor * idisli / rteker;

    % Araç dinamiği
    v_dot = (Fmotor - Faero - Fe - Fmekanik) / m;
    v = v + v_dot * dt;

    % Referans modeli
    vm_dot = -am * vm + bm;
    vm = vm + vm_dot * dt;

    % Hata
    e = v - vm;

    % Adaptasyon yasası (projeksiyon yok!)
    theta1_dot = -gamma1 * e * v;
    theta2_dot = -gamma2 * e * v_ref;

    % Parametre güncellemeleri
    theta1_hat = theta1_hat + theta1_dot * dt;
    theta2_hat = theta2_hat + theta2_dot * dt;

    % Kayıt
    V(k) = v;
    Vm(k) = vm;
    E(k) = e;
    Theta1(k) = theta1_hat;
    Theta2(k) = theta2_hat;
end

% --- Grafikler ---

figure;
plot(t, V, 'b', t, Vm, 'r--', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Hız (m/s)');
legend('Gerçek Hız', 'Referans Hız'); grid on;
title('Standart MRAC: Hız Takibi');

figure;
plot(t, E, 'k', 'LineWidth', 1.2);
xlabel('Zaman (s)'); ylabel('Hata (m/s)');
title('Takip Hatası'); grid on;

figure;
plot(t, Theta1, 'b', t, Theta2, 'r', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('\theta Parametreleri');
legend('\theta_1', '\theta_2'); grid on;
title('Parametre Güncellemeleri');

figure;
plot(t, Tmotor, 'm', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Tork (Nm)');
title('Kontrol Torku'); grid on;
ylim([-150 300]);  % sabit eksen karşılaştırma için
