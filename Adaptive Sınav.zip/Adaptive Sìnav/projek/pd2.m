clc; clear;

% === Sistem Parametreleri ===
m = 1400;              % kg
r = 0.35;              % Tekerlek yarıçapı (m)
F_friction = 182.25;   % N 
C_d = 0.3;             % Sürtünme katsayısı
A = 3;                 % Ön alan (m²)
rho = 1.25;            % Hava yoğunluğu
gear_ratio = 3.58;     % Vites oranı
tau_max = 270;         % Maksimum tork (Nm)
tau_min = -130;        % Minimum tork (Nm)

% === MRAC Parametreleri ===
gamma = 6;             % Öğrenme hızı
a = 0.2;               % Referans model parametresi (sizinti_mrac.m'den)
b = 7;                 % Referans model parametresi (sizinti_mrac.m'den)
theta1_min = -100;     % Projeksiyon sınırları
theta1_max = 100;
theta2_min = -300;
theta2_max = 300;
epsilon = 1;           % Projeksiyon toleransı

% === Simülasyon Ayarları ===
dt = 0.01;
t = 0:dt:300;
v = zeros(size(t));
vm = zeros(size(t));
vref = 35 * ones(size(t)); % 126 km/h
e = zeros(size(t));
tau = zeros(size(t));      % Motor torku (Nm)

% === Başlangıç Koşulları ===
v(1) = 20;                 % Başlangıç hızı (m/s)
vm(1) = 20;
theta1_hat = 0;
theta2_hat = 0;

for k = 1:length(t)-1
    % --- Rüzgar ve Eğim Hesaplaması) ---
    vrand = 10 * sin(0.1 * t(k));       % Rastgele rüzgar
    egim = deg2rad(sin(7));             % 7° eğim
    
    % --- Kuvvet Hesaplamaları) ---
    F_aero = 0.5 * rho * C_d * A * (v(k) + vrand)^2;
    F_slope = m * 9.81 * sin(egim);
    
    % --- Referans Model) ---
    vm(k+1) = vref(k);                  % Sabit referans hız
    
    % --- Hata ---
    e(k) = v(k) - vm(k);
    
    % --- Uyarlama Yasası---
    theta1_dot = -gamma * e(k) * v(k);
    theta2_dot = -gamma * e(k) * vref(k);
   
    % Projeksiyon Operatörü
    if theta1_hat >= theta1_max && theta1_dot / epsilon > 0
        theta1_dot = 0;
    elseif theta1_hat <= theta1_min && theta1_dot / epsilon < 0
        theta1_dot = 0;
    end
    
    if theta2_hat >= theta2_max && theta2_dot / epsilon > 0
        theta2_dot = 0;
    elseif theta2_hat <= theta2_min && theta2_dot / epsilon < 0
        theta2_dot = 0;
    end
    
    theta1_hat = theta1_hat + dt * theta1_dot;
    theta2_hat = theta2_hat + dt * theta2_dot;
    
    % --- Kontrol Girişi ---
    tau(k) = theta1_hat * v(k) + theta2_hat * vref(k);
    tau(k) = max(min(tau(k), tau_max), tau_min); % Tork sınırları
    
    % --- Dinamik Denklem  ---
    F_motor = tau(k) * gear_ratio / r;
    F_total = F_motor - F_aero - F_slope - F_friction;
    v(k+1) = v(k) + dt * (F_total / m);
end

% === Grafikler ===
figure(1);
plot(t, v, 'b', t, vref, 'r--', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Hız (m/s)');
legend('Gerçek Hız', 'Referans Hız'); grid on;
title('Projeksiyonlu MRAC (sizinti\_mrac Dinamikleri ile)');

figure(2);
plot(t, e, 'k', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Hata (m/s)'); grid on;
title('Takip Hatası');

figure(3);
plot(t, tau, 'm', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Tork (Nm)'); grid on;
title('Motor Torku');
ylim([tau_min-10, tau_max+10]);