clc; clear;

% === Simulation parameters ===
dt = 0.01;
t = 0:dt:300;
v = zeros(size(t));
vm = zeros(size(t));
vref = 35 * ones(size(t));
e = zeros(size(t));
u = zeros(size(t));

theta1 = zeros(size(t));
theta2 = zeros(size(t));
theta1_hat = 0;
theta2_hat = 0;

% === System parameters ===
m = 1400;              % kg
r = 0.35;              % wheel radius (m)
F_friction = 182.25;   % N (64.8 km/h'deki hava sürtünmesine eşit)
C_d = 0.3;
A = 3;                 % 2m x 1.5m = 3m²
rho = 1.25;
gear_ratio = 3.58;
tau_max = 270;         % Nm
v_wind = 10;           % 36 km/h = 10 m/s
theta_slope = 7;       % derece

% === MRAC parameters ===
gamma = 6;
a = 1.0;
b = 1.0;
theta1_min = -100;
theta1_max = 100;
theta2_min = -300;
theta2_max = 300;
epsilon = 1;

% === Initial conditions ===
v(1) = 20;             % 20 m/s'den başlat
vm(1) = 20;

for k = 1:length(t)-1
    % Reference model
    vm(k+1) = vm(k) + dt*(-a*vm(k) + b*vref(k));
    e(k) = v(k) - vm(k);

    % Regression vector
    phi = [v(k); vref(k)];

    % Adaptive Law
    theta1_dot = -gamma * e(k) * phi(1);
    theta2_dot = -gamma * e(k) * phi(2);

    % Projection
    if theta1_hat >= theta1_max && theta1_dot / epsilon > 0
        theta1_dot = 0;
    elseif theta1_hat <= theta1_min && theta1_dot / epsilon < 0
        theta1_dot = 0;
    end

    if theta2_hat >= theta2_max && theta2_dot / epsilon > 0
        theta2_dot = 0;
    elseif theta2_hat <= theta2_min && theta2_dot / epsilon < 0
        theta2_dot = 0;
    end

    theta1_hat = theta1_hat + dt * theta1_dot;
    theta2_hat = theta2_hat + dt * theta2_dot;

    theta1(k+1) = theta1_hat;
    theta2(k+1) = theta2_hat;

    % Control input
    u(k) = theta1_hat * v(k) + theta2_hat * vref(k);

    % System dynamics
    F_aero = 0.5 * rho * C_d * A * (v(k) + v_wind)^2; % Rüzgar etkisi
    F_slope = m * 9.81 * sind(theta_slope);           % Eğim etkisi
    F_total = u(k) - F_aero - F_friction - F_slope;   % Yeni kuvvet dengesi
    
    a_real = F_total / m;
    v(k+1) = v(k) + dt * a_real;
end

figure(1)
plot(t, v, 'b', t, vref, 'r--','LineWidth',1.5)
xlabel('Zaman (s)'); ylabel('Hız (m/s)');
title('Hız Takibi');
legend('Gerçek Hız','Referans Hız'); grid on;

figure(2)
plot(t, e, 'k','LineWidth',1.5)
xlabel('Zaman (s)'); ylabel('Hata (m/s)');
title('Takip Hatası (e = v - v_m)'); grid on;

figure(3)
plot(t, theta1, 'b', t, theta2, 'r','LineWidth',1.5)
xlabel('Zaman (s)'); ylabel('\theta Parametreleri');
legend('\theta_1','\theta_2'); title('Parametre Güncellemeleri'); grid on;