
clear; clc;

% Araç parametreleri
m = 1400;
Cd = 0.3; rho = 1.25; A = 3;
idisli = 3.58; rteker = 0.35;
g = 9.81; Fmekanik = 182;

% MRAC parametreleri
gamma1 = 1; 
gamma2 = 1;
sigma1 = 2;
sigma2 = 2;
am = 0.2;
bm = 7;
v_ref = 35;

% Başlangıç değerleri
v = 20;
vm = 20;
theta1_hat = 0;
theta2_hat = 0;

% Zaman ayarları
dt = 0.01;
T = 300;
t = 0:dt:T;

% Kayıt değişkenleri
V = zeros(1, length(t));
Vm = zeros(1, length(t));
E = zeros(1, length(t));
Theta1 = zeros(1, length(t));
Theta2 = zeros(1, length(t));
Tmotor = zeros(1, length(t));

for k = 1:length(t)

    % Rüzgar ve eğim
    vrand = 10 * sin(0.1 * t(k));
    egim = deg2rad(sin(7));

    % Kuvvet hesapları
    Faero = 0.5 * rho * Cd * A * (v + vrand)^2;
    Fe = m * g * sin(egim);

    % Kontrolcü torku
    T_motor = theta1_hat * v + theta2_hat * v_ref;
    T_motor = max(min(T_motor, 270), -130);  % satürasyon
    Tmotor(k) = T_motor;

    % Araç dinamiği
    Fmotor = T_motor * idisli / rteker;
    v_dot = (Fmotor - Faero - Fe - Fmekanik) / m;
    v = v + v_dot * dt;

    % Referans modeli (sabit hız)
    vm = v_ref;

    % Hata
    e = v - vm;

    % Adaptasyon yasası (sızıntılı)
    theta1_dot = -gamma1 * e * v - sigma1 * theta1_hat;
    theta2_dot = -gamma2 * e * v_ref - sigma2 * theta2_hat;

    theta1_hat = theta1_hat + theta1_dot * dt;
    theta2_hat = theta2_hat + theta2_dot * dt;

    % Kayıt
    V(k) = v;
    Vm(k) = vm;
    E(k) = e;
    Theta1(k) = theta1_hat;
    Theta2(k) = theta2_hat;
end

% Grafikler
figure;
plot(t, V, 'b', t, Vm, 'r--', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Hız (m/s)');
legend('Gerçek Hız', 'Referans Hız'); grid on;
title('Sızıntılı MRAC: Hız Takibi (Projeksiyonsuz)');

figure;
plot(t, E, 'k', 'LineWidth', 1.2);
xlabel('Zaman (s)'); ylabel('Hata (m/s)');
title('Takip Hatası'); grid on;

figure;
plot(t, Theta1, 'b', t, Theta2, 'r', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('\theta Parametreleri');
legend('\theta_1', '\theta_2'); grid on;
title('Parametre Güncellemeleri (Sızıntılı)');

figure;
plot(t, Tmotor, 'm', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Tork (Nm)');
title('Motor Torku (Satürasyonlu, Sızıntılı)'); grid on;
ylim([-150 300]);
